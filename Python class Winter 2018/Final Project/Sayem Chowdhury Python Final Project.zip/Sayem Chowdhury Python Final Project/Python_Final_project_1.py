#Sayem Chowdhury
#fr9838
#CSC 4992,Python Programming, Winter Term 2018, Final Project
#---------------------------------------------------------------------

#-----------------[Class Employee]--------------------

class Employee(object):
    
    #Default Constructor method
    def __init__(self, eName="None", eNumber="None"):
        self.__eName =eName
        self.__eNumber=eNumber

    #Accessor method set_eName set the name of the employee
    def set_eName(self, eName):
        self.__eName = eName
        
    #Accessor method set_Number set the employee Number of the employee
    def set_eNumber(self, eNumber):
        self.__eNumber = eNumber

    #Mutator method get_eName return the name of the employee
    def get_eName(self):
        return self.__eName
    
    #Mutator method get_eNumber return the employee number of the employee
    def get_eNumber(self):
        return self.__eNumber

    #method __str__(self) builds and return string representation of the objects state
    def __str__(self):
        return "Employee Name: " + Employee.get_eName(self)+ "\nEmployee Number:" +Employee.get_eNumber(self)+"\n"
    

#-------------------------------------[End of the Class Employee]-------------

#------------
#Test Class Employee 
#E1=Employee("Sayem","Chy")
#print(E1)

#----------------------[Class Production Worker]----------------------------------------

class ProductionWorker(Employee):
    #Default Constructor method
    def __init__(self, eName="None", eNumber="None", sNumber=1, hpRate=0.0):
        
        Employee.__init__(self,eName, eNumber)
        self.__eShiftNumber = sNumber
        self.__eHourlyPayRate = hpRate

    #---------------------------------
    
    #Mutator method set_eName set the name of the production worker/employee
    def set_eName(self, eName):
        Employee.set_eName(self,eName)
        
    #Mutator method set_Number set the employee Number of the production worker/employee
    def set_eNumber(self, eNumber):
        Employee.set_eNumber(self,eNumber)
    
    #Mutator method set_eShistNumber set the employee's Shist Number 
    def set_eShistNumber(self, sNumber):
        self.__eShiftNumber = sNumber
        
    ##Mutator method set_HourlyPayRate set the employee's Hourly Pay Rate  
    def set_eHourlyPayRate(self,hpRate):
        self.__eHourlyPayRate = hpRate


    #getter/accessor Methods
    #Accessor method get_eName return the name of the production worker/employee
    def get_eName(self):
        return Employee.get_eName(self)
    
    #Accessor method get_eNumber return the employee number of the production worker/employee
    def get_eNumber(self):
        return Employee.get_eNumber(self)

    #----------------------------------
    #Accessor method get_eShiftNumber return the Shift Number of the production worker/employee
    def get_eShiftNumber(self):
        return self.__eShiftNumber 
        
    #Accessor method get_eHourlyPayRate return the Hourly Pay Rate of the production worker/employee
    def get_eHourlyPayRate(self):
        return self.__eHourlyPayRate

    #method __str__(self) builds and return string representation of the objects state
    def __str__(self):
        return Employee.__str__(self)+ "Employee Shift Number: "+ str(ProductionWorker.get_eShiftNumber(self))+ \
               "\nEmployee Hourly Pay Rate:"+str(ProductionWorker.get_eHourlyPayRate(self))
    
#-------------------------[End of Class Production Worker]-------------------------------------------------------------------------------------

#Test Class Production Worker
#-------------------------------
#PD1=ProductionWorker()
#print(PD1)

#----------------------------------------------------------

#----------------------------------------[Class Shift Supervisor]--------------------------------------
class ShiftSupervisor(Employee):
    
    #Default Constructor method
    def __init__(self,eName="None",eNumber="None ", AS=0.00, APB=0.00):

        Employee.__init__(self,eName,eNumber)
        self.__sv_Anual_Salary=AS
        self.__sv_Anual_Bonus=APB
        
    #--------------
    #Mutator method set_eName set the name of the Shift Supervisor
    def set_eName(self, eName):
        Employee.set_eName(self,eName)
        
    #Mutator method set_Number set the employee Number of the Shift Supervisor
    def set_eNumber(self, eNumber):
        Employee.set_eNumber(self,eNumber)

    #Mutator method setAS will set the Anual Salary of the Shift Supervisor
    def setAS(self, A_Salary):
        self.__sv_Anual_Salary=A_Salary
    
    #Mutator method setAPB will set the Anual Production Bonus of the Shift Supervisor
    def setAPB(self, APB=0.00):
        self.__sv_Anual_Bonus=APB

#-------------------------
    
    #getter/accessor Methods
        
    #Accessor method get_eName return the name of the Shift Supervisor
    def get_eName(self):
        return Employee.get_eName(self)
    
    #Accessor method get_eNumber return the employee number of the Shift Supervisor
    def get_eNumber(self):
        return Employee.get_eNumber(self,eNumber)
        
    #Accessor method getAPB will return set the Anual Salary  of the Shift Supervisor
    def getAS(self):
        return self.__sv_Anual_Salary;

     
    #Accessor method getAPB will return set the Anual Production Bonus  of the Shift Supervisor
    def getAPB(self):
        return self.__sv_Anual_Bonus

    #method __str__(self) builds and return string representation of the objects state
    def __str__(self):
        return  "Supervisor Name:"+ Employee.get_eName(self)+"\nSupervisor Employee Number:"+Employee.get_eNumber(self)\
                    +"\nSuperVisor Anual Salary :"+ str(self.__sv_Anual_Salary)+"\n"\
                    + "Supervisor Anual Production Bonus:" + str(self.__sv_Anual_Bonus)+"\n"

#--------------------------------------[End of the class shift supervisor]-------------------------------------------

#--------------------
#
#sv=ShiftSupervisor()
#print(sv)
#---------------------


#-------------------------------[main() Method]---------------------------------------------------------------

Emp_Name=input("Please Enter the Name of the Employee:")     
Emp_Number=input("please Enter the Employee Number:")
Emp_Shift_Num=int(input("Please Enter Employee Shift Number: "))
Emp_HP_Rate=float(input("Please Enter the Employee's Hourly Pay Rate:"))
print("\n")

pw=ProductionWorker(Emp_Name,Emp_Number,Emp_Shift_Num,Emp_HP_Rate)

print("Production Employee Information:")
print("--------------------------------")
'''
print("Production Employee Name:"+pw.get_eName()+\
      "\nProduction Employee Number:" +pw.get_eNumber()+\
      "\nProduction Employee Shift:"+str(pw.get_eShiftNumber())+\
      "\nProduction Employee Hourly Pay Rate:"+str(pw.get_eHourlyPayRate())+"\n\n")
'''
      
print(pw)

#-----------------------------------------------
Sup_Name=input("\nPlease Enter the Name of the Supervisor:")     
Sup_Number=input("please Enter the Supervisor Employee Number:")
Sup_A_Salary=float(input("Please Enter the Supervisor's Anual Salary:"))
Sup_AP_Bonus=float(input("Please Enter the Supervisor's Anual Production Bonus:"))

sv=ShiftSupervisor(Sup_Name,Sup_Number,Sup_A_Salary,Sup_AP_Bonus)

print("\n\nSupervisor Information:")
print("-------------------------")
print(sv)

            
#------------------------------------------------------------------------------------------------------------
    


