#Sayem Chowdhury
#fr9838
#CSC 4992,Python Programming, Winter Term 2018, Final Project
#---------------------------------------------------------------------

import turtle
''' Imported turtle graphics module'''
#------------------------------------------

#---------------------------[Class Polygon]---------------------
class Polygon(object):
    ''' Class Polygon will be use to make any shape of n sides in two dimentional platform'''
    
    def __init__(self,nSides,sPoint=(0,0),fcolor="blue",lcolor="black" ):
        ''' Default constructor of the class Polygon, with its private members '''
        
        #private members of the class polygon
        self.__sides = nSides
        self.__startPoint = sPoint
        self.__fillColor = fcolor
        self.__lineColor =lcolor

    def __str__(self):
        ''' method __str__(self) builds and return string representation of the objects state'''
        
        return "a  polygon made up with " + str(self.__sides)+" sides.\n" +\
               "Starting point" + str(self.__startPoint)+"\n"+ "Fill Color:" \
               +self.__fillColor + "\nLine Color:" +self.__lineColor+"\n"
    
    def draw(self, pen):
        ''' method draw will move the turtle object starting point of the drawing shape '''
        
        pen.goto(self.__startPoint[0], self.__startPoint[1]) #turtle object move to the indicating point
        pen.fillcolor(self.__fillColor)
        pen.down()
        pen.begin_fill()
        
#---------------End of the Class polygon---------------------------------------------------------------

#------------------------------------------------------------------------
        
Graphics_Window = turtle.Screen()       # will create a graphics window
pen = turtle.Turtle()                   # declaring a turtle object

#------------------------------------------------------------------------

#-----------------------------
'''
p1=Polygon(3,(2,3), "blue")
print(p1)
p1.draw(pen)
'''
#-----------------------------
#-----------------------------------[Defination of Class Triangle]------------------------------

class Triangle(Polygon):
    ''' Class Triangle inherited from class polygon '''
    
    def __init__(self, v1=(0,0), v2=(90,0), v3=(45,45), fcolor="blue", lcolor="black"):
        '''Default constructor of the class Triangle, with its private members '''
        
        Polygon.__init__(self,3,v1,fcolor,lcolor) # Calling the constructor of the class...
        #...polygon and initializing the members of the class Triangle that inherited  from class Polygon

        # Three vertex of the triangle
        self.__vtx1 = v1
        self.__vtx2 = v2
        self.__vtx3 = v3

    def draw(self,pen):# in method draw parameter pen will pass as a turtle object
        ''' method draw will draw a Triangle '''
        
        Polygon.draw(self,pen)
        pen.goto(self.__vtx2[0],self.__vtx2[1])
        pen.goto(self.__vtx3[0],self.__vtx3[1])
        pen.goto(self.__vtx1[0],self.__vtx1[1])
        pen.up()
        pen.end_fill()

    def __str__(self):
        '''  method __str__(self) builds and return string representation of the objects state  '''
        
        return "Triangle( " + str(self.__vtx1) + ", " + str(self.__vtx2) + ", " + str(self.__vtx3) + " )"

#----------------------------[End of the Class Triangle]-------------------------------------------------

#-------------------------
# Tested Class Triangle
'''
T1=Triangle()
print(T1)
T1.draw(pen)
'''
#-------------------------

#----------------------------[Defination of the class Rectangle]---------------------

class Rectangle(Polygon):
    ''' Class Rectangle inherited from class polygon '''
    
    def __init__(self,v1=(0,0),v2=(200,200),fcolor="blue",lcolor="black"):
        '''  Default constructor of the class Rectangle '''
        
        Polygon.__init__(self,4,v1,fcolor,lcolor)
        self.__vtx1=v1
        self.__vtx2=(v2[0],v1[1])
        self.__vtx3=v2
        self.__vtx4=(v1[0],v2[1])

    def draw(self, pen):
        ''' method draw is overrided for class Rectangle and will draw a rectangle  '''
        
        Polygon.draw(self,pen)
        pen.goto(self.__vtx2[0],self.__vtx2[1])
        pen.goto(self.__vtx3[0],self.__vtx3[1])
        pen.goto(self.__vtx4[0],self.__vtx4[1])
        
        pen.goto(self.__vtx1[0],self.__vtx1[1])
        pen.up()
        pen.end_fill()
        
    def __str__(self):
        ''' method __str__(self) builds and return string representation of the objects state '''
        
        return "Rectagle( "+str(self.__vtx1) + " , " + str(self.__vtx3) + " )"


#------------------------------------[End of the Class Rectangle]---------------------------------
#-------------------------
#Tested Class Rectangle
''' 
R1=Rectangle()
print(R1)
R1.draw(pen)
'''
#---------------------------
#------------------------------------[Defination of the Class Circle]-----------------------------------

class Circle(object):
    ''' Class Circle will create a circle object and draw a circle on two dimentional platform '''
    
    def __init__(self, cent=(10,10), rad=5.0, fcolor="blue", lcolor="black"):
        ''' Default constructor of the class Circle '''
        
        self.center = cent
        self.radius = rad
        self.fillColor = fcolor
        self.lineColor=lcolor
        
    def draw(self, pen):
        '''  method draw is  will draw a Circle '''
        
        pen.goto(self.center[0],self.center[1])
        pen.fillcolor(self.fillColor)
        pen.begin_fill()
        pen.down()
        pen.circle(self.radius)
        pen.up()
        pen.end_fill()

    def __str__(self):
        ''' method __str__(self) builds and return string representation of the objects state '''
        
        return "Circle (" + str(self.center) + ", " + str(self.radius) + " )"

#-------------------------------------[End of the class Circle]----------------------------------------
#-------------------
#Tested class Circle
'''    
c1=Circle()
print(c1)
c1.draw(pen)
'''
#-------------------

#creating and instantitiating class objects
#---------------------------------------------------
Home_Front = Rectangle((0,0) , (200,180),"blue","black")
Window_1 = Rectangle( (30,95), (60,120),"gray","black")
Window_2 = Rectangle( (150,95), (180,120), "gray","black")
Front_Door = Rectangle( (85,0) , (125,90),"green","black")
Home_Roof = Triangle( (0,180), (200, 180), (90,270), "red" ,"black")
Door_Lock = Circle( (92,35),5,"black")

#printing different object instants
#-----------------------------------------
print(Home_Front)
print(Window_1)
print(Window_2)
print(Front_Door)
print(Home_Roof)
print(Door_Lock)


#Using different Shape Drawing a house in graphics window 
#---------------------------------------------------------
Home_Front.draw(pen)
Window_1.draw(pen)
Window_2.draw(pen)
Front_Door.draw(pen)
Home_Roof.draw(pen)
Door_Lock.draw(pen)

#--------------------------------End of the Project----------------------------

