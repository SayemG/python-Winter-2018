#python Assignment:(3)
#Sayem Chowdhury
#-------------------------------------------
from functools import reduce 
#problem(2).A
#--------------------------
#A. Solve this problem using reduce
sentences = ['Mary read a story to Sam and Isla.','Isla cuddled Sam.','Sam chortled.']
sam_count = 0
for sentence in sentences:
 sam_count += sentence.count('Sam')
print ("Sam counted = ",sam_count)

#--------------------------

#Answer: Using reduce method

sentences = ['Mary read a story to Sam and Isla.', 'Isla cuddled Sam.','Sam chortled.']
sam_count = reduce(lambda acumalator, item: acumalator + item.count('Sam'),sentences,0)
print("sam counted using reduce = ", sam_count, "\n\n")

#-------

'''#The initial value of accumulator is different type(a string). So acumulator is
   #specified with a third argument to reduce(). This allows us the  use of
    #a value of a different type from the items in the collection.'''



#Problem (2).B
#------------------------
#B. Rewrite the following code using map
#----------------------------------------
names = ['Mary', 'Isla', 'Sam']
print(names)
for i in range(len(names)):
    names[i] = hash(names[i])
print (names,'\n')

#Answer:
#--------------------------------------------
print("Using Map Function------------------------------")
names= ['Mary', 'Isla', 'Sam']
#print(names)
names=list(map(hash,names))
print(names)
#---------------------------------The end



#---------------------------
'''
#Not Related to this Assignment 
#coments
words=["2", "3", "4", "6"]
words=list(map(int,words))
print(words)
#---------------------------------

a=[2,3,4,1,9,3]
d=list(map(str,a))
print(d)
'''

