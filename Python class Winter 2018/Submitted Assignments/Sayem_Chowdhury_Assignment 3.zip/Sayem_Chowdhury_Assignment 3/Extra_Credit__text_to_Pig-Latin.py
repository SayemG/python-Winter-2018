#Assignment:(3)
#Extra Credit
#Sayem Chowdhury
#pig_latin_Translator
#----------------------Function that convert a word into Pig-Latin--------------
def text_to_pig_latin(aList):        
    vowels=['a','e','i','o','u']
    #text_to_pig_latin(words)
    p_latin=[]
    #Pig_Latin=''

    for word in aList:
        #print(word)
        first_letter=word[0]
        #print(first_letter)
        if first_letter in vowels:
            word=word+"ay"
            #print(word)
            #Pig_Latin=Pig_Latin+" "+word
            p_latin.append(word)
            
        elif first_letter not in vowels:
            last=word[1:]
            word=last+first_letter+'ay'
            #print(word)
            #Pig_Latin=Pig_Latin+" "+word
            p_latin.append(word)
            
    pig_L=" ".join(p_latin)
    print(pig_L)   
    #print(Pig_Latin)
#--------------------------------------------------------------------------
                   
#---------------Main Function------------------------------------
def main():
    #vowels=['a','e','i','o','u']
    text=input("please enter the text to convert the Pig-Latin : \n")
    text=text.lower()
    #print(text)
    words=text.split()
    #print(words)
    
    text_to_pig_latin(words) #function call
    
main() # main function call
#----------------------------------------------------The End


# this function can be implement in main() function

"""
#def text_to_pig_latin(aList):
    #text_to_pig_latin(words)
   #for word in words:
        #print(word)
        first_letter=word[0]
        #print(first_letter)
        if first_letter in vowels:
            word=word+"ay"
            print(word)
            Pig_Latin=Pig_Latin+" "+word
            
        elif first_letter not in vowels:
            last=word[1:]
            word=last+first_letter+'ay'
            print(word)
            Pig_Latin=Pig_Latin+" "+word
    
    print(words)
    print(Pig_Latin)

"""






    
