#assignment #(3)
#Question (1)

def Func(aList):
    global b # sorted value will save(appened) into List b
    
    if (aList==[]):
        return
    else:
        length=len(aList)
        biggest_num=aList[0]
        index=0
        
        for i in range(length):
            if(i<length-1):
                if  biggest_num<aList[i+1]:
                    biggest_num=aList[i+1]
                    index=aList.index(biggest_num)
        
        b.append(biggest_num)
        print(aList.pop(index),end = ",")
        #print(aList)
        #a=a+str(biggest_num)
        Func(aList)#recursive Call to the function

def main():
    global b # global List
    b=[]
    print("please enter 10 positive integers")
    numbers=[]
    count=1
    while(count<11):
        num=int(input("Please enter No("+str(count)+") positive Integer: "))
        if(num<0):
            print("Number must be positive")
        else:
            count=count+1
            numbers.append(num)
    
    print("\nEntered Numbers in List:", numbers,'\n')
    print("Return value of largest number from the list respectivly:\n")
    Func(numbers)
    print("\n\nSorted List:",b)
    
main()  #Function main() is Called      
                


     

                
                
                
            
    
