#Assignment #4
#problem #1
#Sayem Chowdhury
#-----------------------------------------------

class Student(object):
    """Represents a student."""

    
    def __init__(self, name, number):
        """All scores are initially 0."""
        self._name = name
        self._scores = []
        for count in range(number):
            self._scores.append(0)

    
    def getName(self):
        """Returns the student's name."""
        #your code here
        return self._name


    def setScore(self, i, score):
        """Resets the ith score, counting from 1."""
        #your code here
        if i >0 and i <=len(self._scores):
            self._scores[i-1]=score
        else:
            print("Test number is not valid or out of range" )
            
           
    def getScore(self, i):
          """Returns the ith score, counting from 1."""
          #your code here
          return self._score[i-1]

          
    def getAverage(self):
        """Returns the average score."""
        #your code here
        return sum(self._scores)/len(self._scores)

      
    def getHighScore(self):
        """Returns the highest score."""
        #your code here
        return max(self._scores)
    
     
    def __str__(self):
        """Returns the string representation of the student."""
        #your code here
        return "Student Name: "+self.getName()+", Test Scores: "+"["+", ".join( list(map(str, self._scores)))+"]"

#------------------------------------------------------------------------------------------------------------------------

#testing class: 
S1=Student("Hasan",5)
print(S1)

S1.setScore(1,88)
S1.setScore(8,88)
print(S1.getName())
print(S1)
print((S1.getHighScore()))
print((S1.getAverage()))

     
