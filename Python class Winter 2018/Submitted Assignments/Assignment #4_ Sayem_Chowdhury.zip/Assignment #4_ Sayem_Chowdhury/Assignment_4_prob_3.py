#Assignment #4
#Sayem Chowdhury 
#Problem 3 (10 points)
#Suppose class Person is the parent of class Employee. Complete the following code:
#---------------------------------------------------------------------------------------------

class Person:
    def __init__(self, first, last):
        self.firstname = first
        self.lastname = last
        
    def Name(self):
        return self.firstname + " " + self.lastname

    
class Employee(Person):
    def __init__(self, first, last, staffnum):
        """Intialzie firstnames and lastname, staffnumber """
        # write your code here
        Person.__init__(self,first,last)
        self._staffnum=staffnum
        
    def GetEmployee(self):
        """Return Employee’s Name(firstnames and lastname) and staffnumber"""
        # write your code here
        return Person.Name(self)+ "\nStaff Number: " + self._staffnum
    

#-------------Test Code-----------------
    
x = Person("Marge", "Simpson")
y = Employee("Homer", "Simpson", "1007")
print(x.Name())
print(y.GetEmployee())
