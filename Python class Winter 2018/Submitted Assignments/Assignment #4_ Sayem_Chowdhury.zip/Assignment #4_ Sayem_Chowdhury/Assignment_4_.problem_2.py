#Assignment 4
#Sayem Chowdhury 
#Problem 2 (15 points)
'''
Define a class for a restricted saving account that only permits three withdraw per months (see
SavingsAccount class in slides)'''
#-----------------------------------------------------------------------------------------------------

from SavingAccount import SavingsAccount

class RestrictedSavingsAccount(SavingsAccount):
    """This class represents a restricted savings account."""
    MAX_WITHDRAWALS = 3  #static variable of class also constant 

    def __init__(self, name, pin, balance = 10000.00):
        """Same attributes as SavingsAccount, but with a counter for withdrawals."""
        SavingsAccount.__init__(self,name,pin,balance)
        self._counter=0
    
    def withdraw(self, amount):
        """Restricts number of withdrawals to MAX_WITHDRAWALS."""
        if self._counter==RestrictedSavingsAccount.MAX_WITHDRAWALS:
            print("No more withdraw available this month")
            return    
        
        else:
             msg=SavingsAccount.withdraw(self,amount)
             print(msg)
             if msg==None:
                 self._counter+=1
     
             return msg
              

    def resetCounter(self):
        self._counter = 0

    def __str__(self):
        return SavingsAccount.__str__(self) + "\ncounter = " + str (self._counter)
        


#Testing Code
#-----------------------------------------------

w=RestrictedSavingsAccount('Hasan',1234)
print(w)
w.withdraw(200)
print(w)
w.withdraw(900000)
print(w) 

#-------------------------------------------------
#SavingsAccount class code added below 
#-----------------Saving Account Code---------------------------
'''
#Saving _account
class SavingsAccount(object):
    """This class represents a savings accountwith the owner's name, PIN, and balance."""


    RATE = 0.02
    def __init__(self, name, pin, balance = 0.0):
        self._name = name
        self._pin = pin
        self._balance = balance
        
    def __str__(self):
        result = 'Name: ' + self._name + '\n' 
        result += 'PIN: ' + str(self._pin) + '\n'
        result += 'Balance: ' + str(self._balance)
        return result

    def getBalance(self):
        return self._balance
        
    def getName(self):
        return self._name
        
    def getPin(self):
        return self._pin
            
    def deposit(self, amount):
        """Deposits the given amount."""
        self._balance += amount
        return self._balance
        
    def withdraw(self, amount):
        """Withdraws the given amount.Returns None if successful,\
        or anerror message
        if unsuccessful."""
        if amount < 0:
            return 'Amount must be >= 0'
        elif self._balance < amount:
            return 'Insufficient funds'
        else:
            self._balance -= amount
            return None
            
    def computeInterest(self):
            """Computes, deposits, and returns the interest."""
            interest = self._balance * SavingsAccount.RATEself.deposit(interest)
            return interest


'''
#---------------------------------------------------------------------------------------
